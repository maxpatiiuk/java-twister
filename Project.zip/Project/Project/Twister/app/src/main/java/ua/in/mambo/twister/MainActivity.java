package ua.in.mambo.twister;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int[] score;
    int id = 0;
    Random rand = new Random();
    TextView[] button;
    ImageView[] cell;
    TextView resetButton;
    boolean win = false;
    public static final int MAX_SCORE = 9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        score = new int[4];
        button = new TextView[4];
        cell = new ImageView[3];
        button[0] = findViewById(R.id.score1);
        button[1] = findViewById(R.id.score2);
        button[2] = findViewById(R.id.score3);
        button[3] = findViewById(R.id.score4);
        cell[0] = findViewById(R.id.image1);
        cell[1] = findViewById(R.id.image2);
        cell[2] = findViewById(R.id.image3);
        resetButton = findViewById(R.id.reset);
        resetArray();
    }

    protected void resetArray(){
        for(int i=0;i<4;i++)
            score[i]=0;
    }

    protected void play(View view){
        if(win)
            reset();
        if(rand.nextInt(2)==1)
            cell[0].setImageResource(R.drawable.left);
        else
            cell[0].setImageResource(R.drawable.right);
        if(rand.nextInt(2)==1)
            cell[1].setImageResource(R.drawable.hand);
        else
            cell[1].setImageResource(R.drawable.leg);
        int id = rand.nextInt(4);
        if(id==0)
            cell[2].setImageResource(R.drawable.blue);
        else if(id==1)
            cell[2].setImageResource(R.drawable.red);
        else if(id==2)
            cell[2].setImageResource(R.drawable.yellow);
        else
            cell[2].setImageResource(R.drawable.green);
    }

    protected void add(int id){
        if(win)
            reset();
        score[id]++;
        if(score[id]==MAX_SCORE)
            winShow(id);
        display(id);
    }

    protected void add1(View view){
        id=0;
        add(id);
    }
    protected void add2(View view){
        id=1;
        add(id);
    }
    protected void add3(View view){
        id=2;
        add(id);
    }
    protected void add4(View view){
        id=3;
        add(id);
    }

    protected void reset(View view) {
        reset();
    }
    protected void reset(){
        if(win) {
            resetButton.setText("Reset");
            win=false;
        }
        resetArray();
        for(int i=0;i<4;i++)
            display(i);
    }

    protected void display(int id){
        button[id].setText("" + score[id]);
    }

    protected void winShow(int id){
        win=true;
        resetButton.setText("Player "+ (id+1) + " won. Click to reset");
    }
}
